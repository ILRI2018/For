﻿using ForexTransactions.VM.Models;

namespace ForexTransactions.BL.Interfaces
{
    public interface IFileService
    {
        Task CreateCsvFileAsync(DateTime start, DateTime end, int countItems = default);
        Task CreateCopyFileAsync();
        Task SetDataCaseItems();
        Task<ResultProcessVM>ProccesGetErrors();
        Task<ResultDataVM> GetResultData(int page, int perPage, bool isCSV, bool isTransaction);
        Task RemoveDatafileItems();

    }
}
