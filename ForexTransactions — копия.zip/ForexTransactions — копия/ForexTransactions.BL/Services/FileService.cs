﻿using CsvHelper;
using CsvHelper.Configuration;
using ForexTransactions.BL.Interfaces;
using ForexTransactions.DAL.Interfaces;
using ForexTransactions.DAL.Models;
using ForexTransactions.VM.Helpers;
using ForexTransactions.VM.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.Diagnostics;
using System.Drawing.Printing;
using System.Globalization;
using System.Linq.Expressions;
using System.Text;

namespace ForexTransactions.BL.Services
{
    public class FileService : IFileService
    {
        public FileService() { }

        private readonly IUow _uow;
        public FileService(IUow uow)
        {
            _uow = uow;
        }

        private readonly DateTime _start = new DateTime(2024, 1, 1);
        private readonly DateTime _end = new DateTime(2024, 12, 31);

        public async Task CreateCsvFileAsync(DateTime start, DateTime end, int countItems)
        {

            var timer = new Stopwatch();
            timer.Start();

            start = _start;
            end = _end;

            var dates = EnumarateDateRanges(new DateTimeOffset(start), new DateTimeOffset(end)).ToList();
            var lenghtDates = dates.Count;
            var items = Enumerable.Range(1, countItems);

            List<FileItem> files = new List<FileItem>();

           

            Random rnd = new Random();
            bool isStart = true;

            items.AsParallel().WithDegreeOfParallelism(4).ForAll(i =>
            {
                lock (files)
                {
                    var genDateStart = dates[rnd.Next(1, lenghtDates)].start;
                    var genDateEnd = dates[rnd.Next(1, lenghtDates)].end;

                    files.Add(new FileItem
                    {
                        Id = Guid.NewGuid(),
                        Amount = rnd.Next(1, 5000),
                        Description = "test " + genDateStart.ToString(),
                        ProcessedAt = isStart ?
                        genDateStart :
                        genDateEnd,
                        DateInt = DateToInt(genDateStart.Date),
                    });
                    isStart = !isStart;
                }
            });

            var configuration = new CsvConfiguration(CultureInfo.InvariantCulture)
            {
                Encoding = Encoding.UTF8, // Our file uses UTF-8 encoding.
                Delimiter = ",", // The delimiter is a comma.
            };

            int countFiles = countItems / 1000000;

            if (Directory.Exists(Directory.GetCurrentDirectory() + "\\Forex"))
            {
                Directory.Delete(Directory.GetCurrentDirectory() + "\\Forex", true);
            }

            Directory.CreateDirectory(Directory.GetCurrentDirectory() + "\\Forex");

            for (int i = 1; i <= 5; i++)
            {
                string path = Directory.GetCurrentDirectory() + "\\Forex" + "\\forexTransaction" + i + ".csv";

                var filesget = files.Skip(i == 1 ? 0 : (i - 1) * 1000000).Take(1000000);

                using (var fs = File.Open(path, FileMode.OpenOrCreate))
                {
                    using (var textWriter = new StreamWriter(fs, Encoding.UTF8))
                    {
                        using (var csv = new CsvWriter(textWriter, configuration))
                        {
                            csv.WriteRecords(filesget);
                            await _uow.FileEntity.BulkInsertAsync(filesget);
                        }
                    }
                }
            }

            timer.Stop();

            TimeSpan timeTaken = timer.Elapsed;


            await _uow.SaveAsync();

        }

        public async Task CreateCopyFileAsync()
        {
            var predicate = PredicateHelper.GetFilePredicates(DateToInt(_start), DateToInt(_end));
            var listFileItems = await _uow.FileEntity.GetAsync(predicate, disableTracking: true);
            await _uow.TransactionEntity.BulkInsertAsync(listFileItems.Select(x => new Transaction
            {
                Id = Guid.NewGuid(),
                Amount = x.Amount,
                Description = x.Description,
                ProcessedAt = x.ProcessedAt,
                DateInt = DateToInt(x.ProcessedAt.Date),
            }));

            await _uow.SaveAsync();
        }

        private static int DateToInt(DateTime date)
        {
            return date.Year * 10000 + date.Month * 100 + date.Day;
        }

        public async Task SetDataCaseItems()
        {

            var timer = new Stopwatch();
            timer.Start();

            var listFileGenerateItems = await _uow.FileEntity.GetAsync(PredicateHelper.GetFilePredicates(DateToInt(_start), DateToInt(_end)), disableTracking: true, skip: 1000000, take: 200000);
            var listTransactionGenerateItems = await _uow.TransactionEntity.GetAsync(PredicateHelper.GetTransactionPredicates(DateToInt(_start), DateToInt(_end)), disableTracking: true, skip: 500000, take: 900000);



            var listFileNew = new List<FileItem>();
            var listTransactionNew = new List<Transaction>();
            List<FileItem> objectLock = new List<FileItem>();
            List<FileItem> objectLock2 = new List<FileItem>();

            listFileGenerateItems.AsParallel().WithDegreeOfParallelism(4).ForAll(x =>
            {
                lock (objectLock)
                {
                    x.ProcessedAt = x.ProcessedAt.AddHours(3);
                    listFileNew.Add(x);
                }
            });

            listTransactionGenerateItems.AsParallel().WithDegreeOfParallelism(4).ForAll(x =>
            {
                lock (objectLock2)
                {
                    x.Description += "transaction test";
                    listTransactionNew.Add(x);
                }
            });

            await _uow.FileEntity.BulkUpdateAsync(listFileNew);
            await _uow.TransactionEntity.BulkUpdateAsync(listTransactionNew);

            await _uow.SaveAsync();

            timer.Stop();

            TimeSpan timeTaken = timer.Elapsed;

        }

        public async Task<ResultProcessVM> ProccesGetErrors()
        {
            var timer = new Stopwatch();
            timer.Start();

            var listFileItems = (await _uow.FileEntity.GetAsync(PredicateHelper.GetFilePredicates(DateToInt(_start), DateToInt(_end)), disableTracking: true)).ToHashSet();
            var listTransactionItems = (await _uow.TransactionEntity.GetAsync(PredicateHelper.GetTransactionPredicates(DateToInt(_start), DateToInt(_end)), disableTracking: true)).ToHashSet();

            Dictionary<string, List<FileItem>> filesPt1 = new Dictionary<string, List<FileItem>>();
            Dictionary<string, ResultProcessItem> filesPt3 = new Dictionary<string, ResultProcessItem>();
            Dictionary<string, List<Transaction>> transactionsPt1 = new Dictionary<string, List<Transaction>>();
            Dictionary<string, Transaction> transactionsPt2 = new Dictionary<string, Transaction>();
            Dictionary<string, List<Transaction>> transactionsPt3 = new Dictionary<string, List<Transaction>>();

            List<ResultProcessItem> resultProcessItems = new List<ResultProcessItem>();
            var countCycle = (listFileItems.Count / 1000000) + 1;
            Parallel.ForEach(Enumerable.Range(1, countCycle), x =>
            {
                var items = listFileItems.Skip(x == 1 ? 0 : (x - 1) * 1000000).Take(1000000).ToHashSet();
                var items2 = listTransactionItems.Skip(x == 1 ? 0 : (x - 1) * 1000000).Take(1000000).ToHashSet();

                items.AsParallel().WithDegreeOfParallelism(4).ForAll(x =>
                    {

                        lock (filesPt1)
                        {
                            string key = $"{x.Amount}{x.Description}";

                            List<FileItem> list;
                            filesPt1.TryGetValue(key, out list);
                            list = list ?? new List<FileItem>();

                            list.Add(x);

                            if (!filesPt1.ContainsKey(key))
                            {
                                filesPt1.Add(key, list);
                            }
                        }
                    });

                items2.AsParallel().WithDegreeOfParallelism(4).ForAll(y =>
                {
                    lock (transactionsPt1)
                    {
                        string keyPt1 = $"{y.Amount}{y.Description}";
                        List<Transaction> list;
                        transactionsPt1.TryGetValue(keyPt1, out list);
                        list = list ?? new List<Transaction>();

                        list.Add(y);

                        if (!transactionsPt1.ContainsKey(keyPt1))
                        {
                            transactionsPt1.Add(keyPt1, list);
                        }
                    }
                    lock (transactionsPt2)
                    {
                        string keyPt2 = $"{y.Amount}{y.ProcessedAt}";

                        if (!transactionsPt2.ContainsKey(keyPt2))
                        {
                            transactionsPt2.Add(keyPt2, y);
                        }
                    }

                    lock (transactionsPt3)
                    {
                        string keyPt3 = $"{y.Amount}{y.Description}{y.ProcessedAt}";

                        List<Transaction> listPt3;
                        transactionsPt3.TryGetValue(keyPt3, out listPt3);
                        listPt3 = listPt3 ?? new List<Transaction>();

                        listPt3.Add(y);

                        if (!transactionsPt3.ContainsKey(keyPt3))
                        {
                            transactionsPt3.Add(keyPt3, listPt3);
                        }
                    }
                });
            });

            var countCycle2 = (filesPt1.Count / 1000000) + 1;
            Parallel.ForEach(Enumerable.Range(1, countCycle2), x =>
            {
                var items = filesPt1.Skip(x == 1 ? 0 : (x - 1) * 1000000).Take(1000000).ToHashSet();

                items.AsParallel().WithDegreeOfParallelism(8).ForAll(x =>
                {
                    var key = x.Key;
                    var files = x.Value;
                    List<Transaction> transactions;
                    transactionsPt1.TryGetValue(key, out transactions);
                    transactions = transactions ?? new List<Transaction>();

                    foreach (var file in files)
                    {
                        lock (resultProcessItems)
                        {
                            var item = new ResultProcessItem()
                            {
                                Id = Guid.NewGuid(),
                                Amount = file.Amount.ToString(),
                                ProcessedAt = file.ProcessedAt.ToString(),
                                DateInt = file.DateInt,
                                IsCSV = true,
                                IsTransaction = false,
                                Description = file.Description,
                                IsDateChanged = true,
                            };

                            var transaction = transactions.Find(tr => tr.ProcessedAt.AddHours(12) >= file.ProcessedAt && tr.ProcessedAt.AddHours(-12) <= file.ProcessedAt);

                            if (transaction != null)
                            {
                                item.ProcessedAt = transaction.ProcessedAt.ToString();
                                item.IsTransaction = true;
                                item.IsDateChanged = false;
                            }

                            resultProcessItems.Add(item);
                        }
                    }
                });
            });

            var countCycle3 = (resultProcessItems.Count / 1000000) + 1;
            Parallel.ForEach(Enumerable.Range(1, countCycle3), x =>
            {
                var items = resultProcessItems.Skip(x == 1 ? 0 : (x - 1) * 1000000).Take(1000000).ToHashSet();

                items.AsParallel().WithDegreeOfParallelism(8).ForAll(file =>
                {
                    var key = $"{file.Amount}{file.ProcessedAt}";
                    Transaction transaction;
                    transactionsPt2.TryGetValue(key, out transaction);

                        lock (file)
                        {
                            if (transaction != null)
                            {
                                file.IsDescriptionChanged =   file.Description == transaction.Description ? false : true ;
                                file.Description = transaction.Description;
                            }
                        }

                    lock (filesPt3)
                    {
                        string keyPt3 = $"{file.Amount}{file.Description}{file.ProcessedAt}";

                        if (!filesPt3.ContainsKey(keyPt3))
                        {
                            filesPt3.Add(keyPt3, file);
                        }
                    }

                });
            });

            var countCycle4 = (transactionsPt3.Count / 1000000) + 1;

            Parallel.ForEach(Enumerable.Range(1, countCycle4), x =>
            {
                var transactions = transactionsPt3.Skip(x == 1 ? 0 : (x - 1) * 1000000).Take(1000000).ToHashSet();

                    transactions.AsParallel().WithDegreeOfParallelism(8).ForAll(transactionEntry =>
                    {
                        lock (resultProcessItems)
                        {
                            string key = transactionEntry.Key;
                            var transactionsList = transactionEntry.Value;

                            if (!filesPt3.ContainsKey(key))
                            {
                                foreach (var transaction in transactionsList)
                                {
                                    var item = new ResultProcessItem()
                                    {
                                        Id = Guid.NewGuid(),
                                        Amount = transaction.Amount.ToString(),
                                        ProcessedAt = transaction.ProcessedAt.ToString(),
                                        Description = transaction.Description,
                                        IsTransaction = true,
                                        IsCSV = false,
                                    };

                                    resultProcessItems.Add(item);
                                }
                            }
                        }
                    });
            });

            timer.Stop();

            await _uow.ResultEntity.BulkInsertAsync(resultProcessItems);
            await _uow.SaveAsync();

            var result = new ResultProcessVM { SecondsToProcess = timer.Elapsed.TotalSeconds.ToString() };

            return result;

        }

        public async Task RemoveDatafileItems()
        {
            await _uow.FileEntity.ExecuteQueryRawAsync("DELETE FROM FileTransactions", new object[1]);
            await _uow.SaveAsync();
        }

        public Task GetCsvFile()
        {
            return Task.CompletedTask;
        }

        private IEnumerable<(DateTimeOffset start, DateTimeOffset end)> EnumarateDateRanges(DateTimeOffset startDate, DateTimeOffset endDate, bool isPerDay = true)
        {
            bool isPeriod = true;
            DateTimeOffset next;
            DateTimeOffset start;
            if (startDate.Date == endDate.Date || !isPerDay)
            {
                isPeriod = false;
                start = startDate;
                next = GetDatePerType(endDate, isPerDay);
            }
            else
            {
                start = startDate;
                next = GetDatePerType(start, isPerDay);
            }

            while (next <= endDate)
            {
                if (!isPeriod)
                {
                    break;
                }

                yield return (start, next);

                next = GetNextDay(next, isPerDay);
                start = next;

                next = GetDatePerType(start, isPerDay);

                if (start.Month == endDate.Month && start.Year == endDate.Year && next.Date == DateTime.Today)
                {
                    next = endDate.AddDays(-1);
                    break;
                }
            }

            yield return (start, next);
        }

        private DateTimeOffset GetDatePerType(DateTimeOffset date, bool isPerDay)
        {
            return isPerDay ? date.AddHours(23).AddMinutes(59).AddSeconds(59) : date;
        }

        private DateTimeOffset GetNextDay(DateTimeOffset date, bool isPerDay)
        {
            return isPerDay ? date.AddSeconds(1) : date;
        }

        public async Task<ResultDataVM> GetResultData(int page = 1, int perPage = 100, bool isCSV = false, bool isTransaction = false)
        {
            var totalItems = await _uow.ResultEntity.CountAsync(x => x.DateInt >= DateToInt(_start) && x.DateInt <= DateToInt(_end) && x.IsTransaction && x.IsCSV);

            var listResultItems = (await _uow.ResultEntity.GetAsync(
                PredicateHelper.GetResultPredicates(DateToInt(_start), DateToInt(_end) ,isCSV, isTransaction), disableTracking: true, skip: (page - 1) * perPage, take: perPage)).ToList();

            var totalPages = Math.Round((double)(totalItems / perPage), MidpointRounding.AwayFromZero);

            var resultData = new ResultDataVM
            {
                Pagination = new ResultPaginationVM
                {
                    Page = page,
                    PageSize = perPage,
                    TotalCount = totalItems,
                    TotalPages = (int)totalPages,
                },
                ResultDataItems = listResultItems.Select(x => new ResultDataItemVM
                {
                    Amount = x.Amount,
                    Description = x.Description,
                    ProcessedAt = x.ProcessedAt,
                }).ToList(),
            };

            return resultData;
        }
    }
}
