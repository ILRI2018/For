﻿using ForexTransactions.BL.Interfaces;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace ForexTransactions.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("AllowAll")]
    public class FileController : ControllerBase
    {
        private readonly IFileService _fileService;

        public FileController(IFileService fileService)
        {
            _fileService = fileService;
        }

        [HttpDelete("delete-file")]
        public async Task<ActionResult> Delete()
        {
            await _fileService.RemoveDatafileItems();
            return Ok("Success");
        }

        [HttpGet("generate-file")]
        public async Task<ActionResult> Get()
        {
            await _fileService.CreateCsvFileAsync(new DateTime(), new DateTime(), 5000000);

            return Ok("Success");
        }

        [HttpPost("copy-file")]
        public async Task<ActionResult> CopyFile()
        {
            await _fileService.CreateCopyFileAsync();

            return Ok("Success");
        }

        [HttpPost("set-data-cases")]
        public async Task<ActionResult> SetDataCaseItems()
        {
            await _fileService.SetDataCaseItems();

            return Ok("Success");
        }

        [HttpPost("get-data-process-error")]
        public async Task<ActionResult> SetProcessFileErrors()
        {
           var result = await _fileService.ProccesGetErrors();

            return Ok(result.SecondsToProcess);
        }

        [HttpPost("get-result-process-error")]
        public async Task<ActionResult> GetResultErrors(int page, int perPage, bool isCSV, bool isTransaction)
        {
            var result =  await _fileService.GetResultData(page, perPage, isCSV, isTransaction);

            return Ok(result);
        }


    }
}
