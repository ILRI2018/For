﻿using ForexTransactions.DAL.Models;
using ForexTransactions.VM.Models;
using System;
using System.Linq.Expressions;

namespace ForexTransactions.VM.Helpers
{
    public static class PredicateHelper
    {
        public static List<Expression<Func<FileItem, bool>>> GetFilePredicates(int start, int end)
        {
            List<Expression<Func<FileItem, bool>>> predicates = new List<Expression<Func<FileItem, bool>>>();

            if (start != default && end != default)
            {
                predicates.Add(x => x.DateInt >= start && x.DateInt <= end);
            }
            return predicates;
        }

        public static List<Expression<Func<Transaction, bool>>> GetTransactionPredicates(int start, int end)
        {
            List<Expression<Func<Transaction, bool>>> predicates = new List<Expression<Func<Transaction, bool>>>();

            if (start != default && end != default)
            {
                predicates.Add(x => x.DateInt >= start && x.DateInt <= end);
            }
            return predicates;
        }

        public static List<Expression<Func<ResultProcessItem, bool>>> GetResultPredicates(int start, int end, bool isCSV, bool IsTransaction)
        {
            List<Expression<Func<ResultProcessItem, bool>>> predicates = new List<Expression<Func<ResultProcessItem, bool>>>();

            if (start != default && end != default)
            {
                predicates.Add(x => x.DateInt >= start && x.DateInt <= end);
            }
            if (isCSV)
            {
                predicates.Add(x => x.IsCSV == true);
            }
            if (IsTransaction)
            {
                predicates.Add(x => x.IsTransaction == true);
            }

            return predicates;
        }
    }
}
