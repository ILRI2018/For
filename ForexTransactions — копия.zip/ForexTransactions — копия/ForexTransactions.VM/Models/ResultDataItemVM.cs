﻿namespace ForexTransactions.VM.Models
{
    public class ResultDataItemVM
    {
        public string Amount { get; set; }
        public string Description { get; set; }
        public string ProcessedAt { get; set; }
    }
}
