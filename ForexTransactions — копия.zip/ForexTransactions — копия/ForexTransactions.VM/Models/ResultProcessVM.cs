﻿namespace ForexTransactions.VM.Models
{
    public class ResultProcessVM
    {
        public string SecondsToProcess { get; set; }
    }
}
