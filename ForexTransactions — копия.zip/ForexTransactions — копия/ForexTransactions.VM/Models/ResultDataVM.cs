﻿namespace ForexTransactions.VM.Models
{
    public class ResultDataVM
    {
        public ResultPaginationVM Pagination { get; set; }
        public List<ResultDataItemVM> ResultDataItems { get; set; }
    }
}
