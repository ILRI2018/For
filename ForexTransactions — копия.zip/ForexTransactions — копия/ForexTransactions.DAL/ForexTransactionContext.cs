﻿using ForexTransactions.DAL.Models;
using ForexTransactions.VM.Models;
using Microsoft.EntityFrameworkCore;

namespace ForexTransactions.DAL
{
    public class ForexTransactionContext : DbContext
    {
        public ForexTransactionContext()
        {
            Database.EnsureDeleted();
            Database.EnsureCreated();
            Database.Migrate();
        }
        public ForexTransactionContext(DbContextOptions options) : base(options) { }

        public DbSet<Transaction> Transactions { get; set; }
        public DbSet<FileItem> FileTransactions { get; set; }
        public DbSet<ResultProcessItem> ResultTransactions { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

        }
    }
}
