﻿using ForexTransactions.DAL.Interfaces;
using ForexTransactions.DAL.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query;
using System.Data;
using System.Linq.Expressions;

namespace ForexTransactions.DAL.Repositories
{
    public class GenericRepository<T> : IGenericRepository<T> where T : class
    {
        private readonly ForexTransactionContext _context;
        private readonly DbSet<T> _dbSet;

        public GenericRepository(ForexTransactionContext context)
        {
            _context = context;
            _dbSet = context.Set<T>();
        }

        public void Add(T entity)
        {
            
            _dbSet.Add(entity);
        }

        public async Task<int> CountAsync(Expression<Func<T, bool>> predicate = null)
        {
            IQueryable<T> query = _context.Set<T>();
            if (predicate != null)
            {
                query = query.Where(predicate);
            }
            return await query.CountAsync();
        }

        public void AddRange(IEnumerable<T> entities)
        {
            _dbSet.AddRange(entities);
        }

        public void BulkInsert(IEnumerable<T> entities)
        {
           _dbSet.BulkInsert(entities);
        }

        public async Task BulkInsertAsync(IEnumerable<T> entities)
        {
            await _dbSet.BulkInsertAsync(entities);
        }

        public async Task BulkUpdateAsync(IList<T> entities)
        {
            await _dbSet.BulkUpdateAsync(entities);
        }

        public async Task BulkDeleteAsync(IEnumerable<T> entities)
        {
            await _dbSet.BulkDeleteAsync(entities);
        }

        public Task<int> ExecuteQueryRawAsync(string query, IEnumerable<object> parameters, CancellationToken cancellationToken = default)
        {
            return _context.Database.ExecuteSqlRawAsync(query, parameters, cancellationToken);
        }

        public IEnumerable<T> Find(Expression<Func<T, bool>> expression)
        {
            return _dbSet.Where(expression);
        }

        public IEnumerable<T> GetAll()
        {
            return _dbSet.ToList();
        }
        public async Task<IList<T>> GetAsync(List<Expression<Func<T, bool>>> predicates,
           Func<IQueryable<T>, IOrderedQueryable<T>> orderBy = null,
           Func<IQueryable<T>, IIncludableQueryable<T, object>> include = null,
           bool disableTracking = false, int skip = 0, int take = 0,
           CancellationToken cancellationToken = default)
        {
            IQueryable<T> query = _dbSet;

            if (disableTracking)
            {
                query = query.AsNoTracking();
            }

            if (include != null)
            {
                query = include(query);
            }

            if (predicates != null)
            {
                foreach (var predicate in predicates)
                {
                    query = query.Where(predicate);
                }
            }

            if (skip > 0) query = query.Skip(skip);

            if (take > 0) query = query.Take(take);

            if (orderBy != null)
            {
                return await orderBy(query).ToListAsync(cancellationToken);
            }
            else
            {
                return await query.ToListAsync(cancellationToken);
            }
        }

        public T GetById(Guid id)
        {
            return _dbSet.Find(id);
        }

        public IQueryable<T> GetQueryable()
        {
            return _dbSet.AsQueryable<T>();
        }

        public void Remove(T entity)
        {
            _dbSet.Remove(entity);
        }

        public void RemoveRange(IEnumerable<T> entities)
        {
            _dbSet.RemoveRange(entities);
        }
    }
}
