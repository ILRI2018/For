﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace ForexTransactions.VM.Models
{
    [Index("DateInt")]
    public class ResultProcessItem
    {
        public Guid Id { get; set; }
        [MaxLength(30, ErrorMessage = "Maximum 30 characters")]
        public string Amount { get; set; }
        [MaxLength(250, ErrorMessage = "Maximum 250 characters")]
        public string Description { get; set; }
        [MaxLength(250, ErrorMessage = "Maximum 250 characters")]
        public string ProcessedAt { get; set; }
        public int DateInt { get; set; }
        public bool IsCSV { get; set; }
        public bool IsTransaction { get; set; }
        public bool IsDateChanged { get; set; }
        public bool IsDescriptionChanged { get; set; }
    }
}
