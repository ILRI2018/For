﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace ForexTransactions.DAL.Models
{
    [Index("DateInt")]
    public class FileItem
    {
        public Guid Id { get; set; }
        [Precision(14, 6)]
        public decimal Amount { get; set; }
        [MaxLength(250, ErrorMessage = "Maximum 250 characters")]
        public string Description { get; set; }
        public DateTimeOffset ProcessedAt { get; set; }
        public int DateInt { get; set; }
    }
}
