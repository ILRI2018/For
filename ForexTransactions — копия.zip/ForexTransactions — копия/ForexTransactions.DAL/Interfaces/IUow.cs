﻿using ForexTransactions.DAL.Models;
using ForexTransactions.VM.Models;

namespace ForexTransactions.DAL.Interfaces
{
    public interface IUow: IDisposable
    {
        public IGenericRepository<Transaction> TransactionEntity { get; }
        public IGenericRepository<FileItem> FileEntity { get; }
        public IGenericRepository<ResultProcessItem> ResultEntity { get; }

        public Task SaveAsync(CancellationToken cancellationToken = default);
    }
}
