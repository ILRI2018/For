﻿using ForexTransactions.DAL.Interfaces;
using ForexTransactions.DAL.Models;
using ForexTransactions.DAL.Repositories;
using ForexTransactions.VM.Models;

namespace ForexTransactions.DAL.Uow
{
    public class Uow : IUow
    {
        private readonly ForexTransactionContext _context;

        private IGenericRepository<Transaction> _transactionEntity;
        private IGenericRepository<FileItem> _fileEntity;
        private IGenericRepository<ResultProcessItem> _resultEntity;

        private bool disposedValue;

        public Uow(ForexTransactionContext context)
        {
            _context = context;
        }

        public IGenericRepository<Transaction> TransactionEntity => _transactionEntity ??= new GenericRepository<Transaction>(_context);
        public IGenericRepository<FileItem> FileEntity => _fileEntity ??= new GenericRepository<FileItem>(_context);
        public IGenericRepository<ResultProcessItem> ResultEntity => _resultEntity ??= new GenericRepository<ResultProcessItem>(_context);


        public Task SaveAsync(CancellationToken cancellationToken = default)
        {
            return _context.SaveChangesAsync(cancellationToken);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposedValue)
            {
                return;
            }

            if (disposing)
                _context?.Dispose();

            disposedValue = true;
        }
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
            Dispose(disposing: true);
            GC.SuppressFinalize(this);
        }
    }
}
