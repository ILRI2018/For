﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ForexTransactions.DAL.Migrations
{
    public partial class CreateIndex : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_Transactions_ProcessedAt",
                table: "Transactions",
                column: "ProcessedAt");

            migrationBuilder.CreateIndex(
                name: "IX_FileTransactions_ProcessedAt",
                table: "FileTransactions",
                column: "ProcessedAt");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Transactions_ProcessedAt",
                table: "Transactions");

            migrationBuilder.DropIndex(
                name: "IX_FileTransactions_ProcessedAt",
                table: "FileTransactions");
        }
    }
}
