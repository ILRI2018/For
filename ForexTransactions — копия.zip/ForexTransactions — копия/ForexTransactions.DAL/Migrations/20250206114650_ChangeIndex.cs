﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ForexTransactions.DAL.Migrations
{
    public partial class ChangeIndex : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Transactions_ProcessedAt",
                table: "Transactions");

            migrationBuilder.DropIndex(
                name: "IX_FileTransactions_ProcessedAt",
                table: "FileTransactions");

            migrationBuilder.AddColumn<int>(
                name: "DateInt",
                table: "Transactions",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "DateInt",
                table: "FileTransactions",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Transactions_DateInt",
                table: "Transactions",
                column: "DateInt");

            migrationBuilder.CreateIndex(
                name: "IX_FileTransactions_DateInt",
                table: "FileTransactions",
                column: "DateInt");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Transactions_DateInt",
                table: "Transactions");

            migrationBuilder.DropIndex(
                name: "IX_FileTransactions_DateInt",
                table: "FileTransactions");

            migrationBuilder.DropColumn(
                name: "DateInt",
                table: "Transactions");

            migrationBuilder.DropColumn(
                name: "DateInt",
                table: "FileTransactions");

            migrationBuilder.CreateIndex(
                name: "IX_Transactions_ProcessedAt",
                table: "Transactions",
                column: "ProcessedAt");

            migrationBuilder.CreateIndex(
                name: "IX_FileTransactions_ProcessedAt",
                table: "FileTransactions",
                column: "ProcessedAt");
        }
    }
}
