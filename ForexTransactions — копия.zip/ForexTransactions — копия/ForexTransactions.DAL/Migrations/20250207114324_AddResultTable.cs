﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ForexTransactions.DAL.Migrations
{
    public partial class AddResultTable : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ResultTransactions",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Amount = table.Column<string>(type: "nvarchar(30)", maxLength: 30, nullable: true),
                    Description = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: true),
                    ProcessedAt = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: true),
                    DateInt = table.Column<int>(type: "int", nullable: false),
                    IsCSV = table.Column<bool>(type: "bit", nullable: false),
                    IsTransaction = table.Column<bool>(type: "bit", nullable: false),
                    IsDateChanged = table.Column<bool>(type: "bit", nullable: false),
                    IsDescriptionChanged = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ResultTransactions", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_ResultTransactions_DateInt",
                table: "ResultTransactions",
                column: "DateInt");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ResultTransactions");
        }
    }
}
